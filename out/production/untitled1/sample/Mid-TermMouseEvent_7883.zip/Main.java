package sample;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.EventHandler;

import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Main extends Application {
    static int count = 0;
    @Override
    public void start(Stage stage) {

        //Drawing a Circle
        Circle circle = new Circle();

        //Setting the position of the circle
        circle.setCenterX(200);
        circle.setCenterY(200);

        //Setting the radius of the circle
        circle.setRadius(50);

        //Setting the color of the circle
        circle.setFill(Color.RED);

        //Setting the text
        Text text = new Text("Mouse Exited");
        text.setVisible(false);

        //setting the position of the text
        text.setX(0);
        text.setY(20);

        
        circle.setOnMouseExited (new EventHandler<javafx.scene.input.MouseEvent>() {
            @Override
            public void handle(javafx.scene.input.MouseEvent e) {
                circle.setFill(Color.GREEN);
                circle.setRadius(50);
                text.setVisible(true);
            }
        });

        circle.setOnMouseEntered (new EventHandler<javafx.scene.input.MouseEvent>() {
            @Override
            public void handle(javafx.scene.input.MouseEvent e) {
                text.setText("Mouse Entered");
                circle.setFill(Color.YELLOW);
                circle.setRadius(100);
                text.setVisible(true);
            }
        });


        circle.setOnMouseClicked (new EventHandler<javafx.scene.input.MouseEvent>() {
            @Override
            public void handle(javafx.scene.input.MouseEvent e) {
                count++;
                text.setText("Mouse Clicked, Click count = " + count + ", X = " + e.getSceneX() + ", Y = " + e.getSceneY() + "");
                circle.setFill(Color.BLUE);
                circle.setRadius(70);
                text.setVisible(true);
            }
        });

        //Creating a Group object
        Group root = new Group(circle, text);

        //Creating a scene object
        Scene scene = new Scene(root, 400, 400);

        //Setting the fill color to the scene
        scene.setFill(Color.LAVENDER);

        //Setting title to the Stage
        stage.setTitle("Event Filters Example");

        //Adding scene to the stage
        stage.setScene(scene);

        //Displaying the contents of the stage
        stage.show();
    }
    public static void main(String args[]){
        launch(args);
    }
}